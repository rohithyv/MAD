package com.example.calc;

interface MainActivity1 {
}
